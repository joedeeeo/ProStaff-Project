package com.prostaff.service.team.inter_service_communication.enums;

public enum LeaveRequestType {
	PAID, UNPAID, SICK
}
