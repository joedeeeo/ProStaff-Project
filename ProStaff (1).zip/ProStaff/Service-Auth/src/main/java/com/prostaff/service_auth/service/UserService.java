package com.prostaff.service_auth.service;


import com.prostaff.service_auth.dto.LoginRequest;
import com.prostaff.service_auth.dto.LoginResponse;
import com.prostaff.service_auth.inter_service_communication.dto.AuthRequest;
import com.prostaff.service_auth.inter_service_communication.dto.EmployeeEmailWrapper;
import com.prostaff.service_auth.inter_service_communication.dto.NewUser;

public interface UserService {
	
	public Boolean addUser(NewUser newUser);
	public Boolean deleteUser(EmployeeEmailWrapper employeeEmailWrapper);
	public LoginResponse login(LoginRequest loginRequest);
	public Integer validate(AuthRequest authRequest);
	public Boolean isUserExist(EmployeeEmailWrapper employeeEmailWrapper);
	public String getUserOrganization(EmployeeEmailWrapper employeeEmailWrapper);
	public String getFullName(EmployeeEmailWrapper employeeEmailWrapper);
	
}
