package com.prostaff.service_auth.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.prostaff.service_auth.domian.User;
import com.prostaff.service_auth.dto.LoginRequest;
import com.prostaff.service_auth.dto.LoginResponse;
import com.prostaff.service_auth.inter_service_communication.dto.AuthRequest;
import com.prostaff.service_auth.inter_service_communication.dto.EmployeeEmailWrapper;
import com.prostaff.service_auth.inter_service_communication.dto.NewUser;
import com.prostaff.service_auth.inter_service_communication.enums.Role;
import com.prostaff.service_auth.repository.UserRepository;
import com.prostaff.service_auth.service.UserService;
import com.prostaff.service_auth.utils.JwtUtils;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository db;
	
	@Autowired
	private JwtUtils jwtUtils;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;
	
	@Override
	public Boolean addUser(NewUser newUser) {
		User entity = new User();
		
		if(db.existsById(newUser.getEmail())) return false;
		
		entity.setEmail(newUser.getEmail());
		entity.setPassword(newUser.getPassword());
		entity.setFullName(newUser.getFullName());
		entity.setOrganizationName(newUser.getOrganizationName());
		entity.setRole(Role.EMPLOYEE);
		
		db.save(entity);
		return true;
	}

	@Override
	public Boolean deleteUser(EmployeeEmailWrapper employeeEmailWrapper) {
		if(!db.existsById(employeeEmailWrapper.getEmployeeEmail())) return false;
		
		db.deleteById(employeeEmailWrapper.getEmployeeEmail());
		
		return true;
	}

	@Override
	public LoginResponse login(LoginRequest loginRequest) {
		
		if(!db.existsById(loginRequest.getEmail()) || !passwordEncoder.matches(loginRequest.getPassword(), db.findById(loginRequest.getEmail()).get().getPassword()))
		{
			return new LoginResponse("FAILED", Role.EMPLOYEE);
		}
		
		LoginResponse loginResponse = new LoginResponse(jwtUtils.generateToken(loginRequest.getEmail()), db.findById(loginRequest.getEmail()).get().getRole());
		return loginResponse;
	}

	@Override
	public Integer validate(AuthRequest authRequest) {
		// pending
		return 0;
	}

	@Override
	public Boolean isUserExist(EmployeeEmailWrapper employeeEmailWrapper) {
		return db.existsById(employeeEmailWrapper.getEmployeeEmail());
	}

	@Override
	public String getUserOrganization(EmployeeEmailWrapper employeeEmailWrapper) {
		if(!db.existsById(employeeEmailWrapper.getEmployeeEmail())) return "";
		return db.findById(employeeEmailWrapper.getEmployeeEmail()).get().getOrganizationName();
	}

	@Override
	public String getFullName(EmployeeEmailWrapper employeeEmailWrapper) {
		if(!db.existsById(employeeEmailWrapper.getEmployeeEmail())) return "NO SUCH USER EXIST";
		return db.findById(employeeEmailWrapper.getEmployeeEmail()).get().getFullName();
	}
	
}
