package com.prostaff.service.leave.request.exception;

public class LeaveRequestNotFoundException extends RuntimeException{

}
