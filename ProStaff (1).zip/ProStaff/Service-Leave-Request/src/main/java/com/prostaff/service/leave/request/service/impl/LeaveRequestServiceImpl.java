package com.prostaff.service.leave.request.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prostaff.service.leave.request.entity.LeaveRequest;
import com.prostaff.service.leave.request.inter_service_communication.dto.AdminEmailWrapper;
import com.prostaff.service.leave.request.inter_service_communication.dto.EmployeeEmailWrapperWithOnlyPending;
import com.prostaff.service.leave.request.repository.LeaveRequestRepo;
import com.prostaff.service.leave.request.service.LeaveRequestService;

@Service
public class LeaveRequestServiceImpl implements LeaveRequestService{

	@Autowired
	private LeaveRequestRepo leaveRequestRepo;

	@Override
	public List<LeaveRequest> getAllLeaveRequests(AdminEmailWrapper adminEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean createRequest(LeaveRequest leaveRequest) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<LeaveRequest> getEmployeeLeaveRequest(EmployeeEmailWrapperWithOnlyPending employeePending) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean grant(Long id, AdminEmailWrapper adminEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deny(Long id, AdminEmailWrapper adminEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}
}
