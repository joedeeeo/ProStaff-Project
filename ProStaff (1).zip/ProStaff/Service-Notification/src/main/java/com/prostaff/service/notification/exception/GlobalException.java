package com.prostaff.service.notification.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalException {

	@ExceptionHandler(value = TeamNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ErrorResponse handleTeamNotFoundException(TeamNotFoundException e) {
		return new ErrorResponse("Team not found",10);
	}
	
	@ExceptionHandler(value = TeamAlreadyExistsException.class)
	@ResponseStatus(value = HttpStatus.ALREADY_REPORTED)
	public ErrorResponse handleTeamAlreadyExistsException(TeamAlreadyExistsException e) {
		return new ErrorResponse("Team already exist",11);
	}
	
	
}
