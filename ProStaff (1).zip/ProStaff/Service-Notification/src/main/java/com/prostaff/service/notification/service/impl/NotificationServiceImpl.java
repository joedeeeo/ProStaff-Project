package com.prostaff.service.notification.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prostaff.service.notification.inter_service_communication.dto.AdminEmailWrapper;
import com.prostaff.service.notification.inter_service_communication.dto.EmployeeEmailWrapper;
import com.prostaff.service.notification.inter_service_communication.dto.NewNotification;
import com.prostaff.service.notification.inter_service_communication.dto.NotificationDetails;
import com.prostaff.service.notification.inter_service_communication.dto.NotificationFilter;
import com.prostaff.service.notification.repository.NotificationRepository;
import com.prostaff.service.notification.service.NotificationService;

@Service
public class NotificationServiceImpl implements NotificationService{

	@Autowired
	private NotificationRepository notificationRepo;

	@Override
	public Boolean addNotification(NewNotification newNotification) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deleteNotification(Long id, AdminEmailWrapper adminEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NotificationDetails> getEmployeeNotification(EmployeeEmailWrapper employeeEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NotificationDetails> getAllNotifications() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<NotificationDetails> getFilteredNotifications(NotificationFilter notificationFilter) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean updateNotificationMessage(Long id, AdminEmailWrapper adminEmailWrapper) {
		// TODO Auto-generated method stub
		return null;
	}
}
