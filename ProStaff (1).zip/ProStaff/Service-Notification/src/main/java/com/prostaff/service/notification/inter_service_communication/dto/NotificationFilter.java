package com.prostaff.service.notification.inter_service_communication.dto;

import java.util.List;

import lombok.Data;

@Data
public class NotificationFilter {

	List<String> teams;
	List<String> departments;
	List<String> designations;
}
