package com.prostaff.service.attendance.inter_service_communication.enums;

public enum LeaveRequestType {
	PAID, UNPAID, SICK
}
