package com.prostaff_service_admin_logger.inter_service_communication.dto;

public class EmployeeEmailWrapperWithOnlyPending {
	
	String employeeEmail; 
	Boolean onlyPending;
	
}
